create database Cadastro_PF;
use Cadastro_PF;

create table pessoa(
id int,
nome_completo varchar(90),
idade int,
genero varchar(60),
nacionalidade varchar(20),
email varchar(30),
estado_civil varchar(30),
nome_P varchar(90),
nome_M varchar(90)
);
 
insert into pessoa values(1234,"Marcus Paulo Silva De Oliveira",19,"masculino","Brasileiro","marcusjanairson812@gmail.com","solteiro","Hamilton Tadeu Sande de Oliveira","Sonia Teixeira da Silva de Oliveira");
insert into pessoa values(3435,"Juan Bartolomé De Las Casas",24,"masculino","Paraguaio","Lascasasbart0123@hotmail.com","solteiro","Homeró Simpósio de las casas","Marie Bovier de las casas y trinidad");
insert into pessoa values(4565,"Janny hoover smithson",20,"feminino","Estadunidense","TheonlyJannyMJ347@hotmail.com","solteira","John edward Hoover","Mary johnson Smithson" );
insert into pessoa values(9875,"Celso Barreto Costa Filho",40,"masculino","Brasileiro","csmconsultoria874@gmail.com","Casado","Cassiano Barreto dos Santos Costa","Sandra Pires Andrade Filho");
alter table pessoa;
Delete from pessoa where id=9875;
select *from pessoa