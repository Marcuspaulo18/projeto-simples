
import pymysql

##dados de acesso ao banco de dados
DB_HOST = '127.0.0.1'  # Endereço do banco de dados
DB_USER = 'root'  # Usuário do banco de dados
DB_PASSWORD = '7890_6543'  # Senha do banco de dados
DB_NAME = 'infinito'  # Nome do banco de dados

# Abrir conexão com o banco de dados
conexao = pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME)



# Função para autenticar o usuário (verificar se o e-mail e senha correspondem)
def autenticar_usuario(email, senha):
    try:
        with conexao.cursor() as cursor:
            # Consulta SQL para verificar se o e-mail está cadastrado e a senha está correta
            sql = f"SELECT * FROM `cadastro` WHERE `cadastro_email` = %s AND `cadastro_senha` = %s"
            cursor.execute(sql, (email, senha))  # Executar a consulta SQL com os parâmetros
            resultado = cursor.fetchone()  # Retornar uma linha se encontrar correspondência
            return resultado is not None  # Retornar True se encontrar uma correspondência, False caso contrário
    except pymysql.Error as e:
        print(f"Erro ao autenticar usuário: {e}")  # Se ocorrer um erro, imprimir a mensagem de erro
        return False



# Função para inserir dados em uma tabela
def inserir_dados_em_tabela(tabela, campos_colunas, linha):
    try:
        with conexao.cursor() as cursor:
            # Query SQL para inserir os dados na tabela
            sql = f"INSERT INTO `{DB_NAME}`.`{tabela}` ({campos_colunas}) VALUES ({linha})"
            cursor.execute(sql)  # Executar a query SQL
        conexao.commit()  # Confirmar a inserção no banco de dados
    except pymysql.Error as e:
        print(f"Erro ao inserir dados na tabela: {e}")  # Se ocorrer um erro, imprimir a mensagem de erro
