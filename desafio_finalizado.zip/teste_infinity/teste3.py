import pymysql

# Database credentials
DB_HOST = '127.0.0.1'
DB_USER = 'root'
DB_PASSWORD = '7890_6543'
DB_NAME = 'test_inf'

# Establish a connection
conexao = pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME)

def atualiza_banco_via_id(tabela, coluna, novo_dado, id):
    """
    Atualiza um valor em uma coluna específica de uma tabela com base no ID fornecido.

    Args:
        tabela (str): Nome da tabela a ser atualizada.
        coluna (str): Nome da coluna a ser atualizada.
        novo_dado (str): Novo valor para a coluna.
        id (int): ID do registro a ser atualizado.
    """
    with conexao.cursor() as cursor:
        sql = "UPDATE `test_inf`.`%s` SET `%s` = %%s WHERE (`id` = %%s)" % (tabela, coluna)
        cursor.execute(sql, (novo_dado, id))
        conexao.commit()

def mostrar_tabela(tabela):
    """
    Exibe todos os registros de uma tabela.

    Args:
        tabela (str): Nome da tabela a ser consultada.
    Returns:
        list: Lista de dicionários contendo os dados dos registros.
    """
    with conexao.cursor() as cursor:
        sql = "SELECT * FROM test_inf.%s" % tabela
        cursor.execute(sql)
        resultados = cursor.fetchall()
        return resultados

def inserir_dados_em_tabela(tabela, campos_colunas, linha):
    """
    Insere um novo registro em uma tabela.

    Args:
        tabela (str): Nome da tabela a ser inserida.
        campos_colunas (str): String contendo os nomes das colunas separadas por vírgulas.
        linha (tuple): Tupla contendo os valores para as colunas, na mesma ordem.
    """
    with conexao.cursor() as cursor:
        sql = "INSERT INTO %s (%s) VALUES (%s)" % (tabela, campos_colunas, linha)
        cursor.execute(sql, linha)
        conexao.commit()

# Example usage
inserir_dados_em_tabela(tabela='usuario',campos_colunas= 'nome,email',linha= '"hhfhfgh", "868686"')

