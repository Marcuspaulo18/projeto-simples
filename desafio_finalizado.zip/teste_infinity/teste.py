import pymysql

def execute_query(conexao, table_name):
    try:
        with conexao.cursor() as cursor:
            sql = f"SELECT * FROM {table_name}"
            cursor.execute(sql)
            resultados = cursor.fetchall()
            for resultado in resultados:
                print(resultado)
    except pymysql.Error as e:
        print(f"Error executing query: {e}")

# Establish a connection
conexao = pymysql.connect(
    host='127.0.0.1',
    user='root',
    password='7890_6543',
    database='test_inf',
    charset='utf8mb4',
    cursorclass=pymysql.cursors.DictCursor
)

try:
    # Execute queries
    execute_query(conexao, 'endereco')
    execute_query(conexao, 'entrega')
    execute_query(conexao, 'usuario')
finally:
    # Close the connection
    conexao.close()