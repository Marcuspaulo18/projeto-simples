import pymysql

##dados

DB_HOST = '127.0.0.1'
DB_USER = 'root'
DB_PASSWORD = '7890_6543'
DB_NAME = 'test_inf'

#abrir conexao
conexao = pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME)
cursor = conexao.cursor()


##atualiza banco

def atualiza_banco_via_id(tabela, coluna, novo_dado, id):
    cursor = conexao.cursor()
    sql = f"UPDATE `test_inf`.`{tabela}` SET `{coluna}` = '{novo_dado}' WHERE (`id` = '{id}');"
    cursor.execute(sql)
    cursor.close()

def mostrar_tabela(tabela):
    cursor = conexao.cursor()
    sql = f"SELECT * FROM test_inf.{tabela};"
    cursor.execute(sql)
    resultados = cursor.fetchall()
    return resultados
    cursor.close()

def inserir_dados_em_tabela(tabela, campos_colunas, linha):
    cursor = conexao.cursor()
    sql = f"INSERT INTO {tabela} ({campos_colunas}) VALUES ({linha})"
    cursor.execute(sql)
    cursor.close()
    inserir_dados_em_tabela(tabela='usuario', campos_colunas='nome,email ', linha=' "hhfhfgh", "868686"')


