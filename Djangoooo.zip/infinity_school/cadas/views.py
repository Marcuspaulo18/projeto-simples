from django.shortcuts import render, redirect
from .forms import CadastroModuloForm, FluxoModulosForm

def cadastro_modulo(request):
    if request.method == 'POST':
        form = CadastroModuloForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('cadastro_modulo')  # Redireciona para a mesma página após o salvamento
    else:
        form = CadastroModuloForm()

    context = {'form': form}
    return render(request, 'cadastro_modulo.html', context)


def fluxo_modulos(request):
    if request.method == 'POST':
        form = FluxoModulosForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('fluxo_modulos')  # Redireciona para a mesma página após o salvamento
    else:
        form = FluxoModulosForm()

    context = {'form': form}
    return render(request, 'fluxo_modulos.html', context)
