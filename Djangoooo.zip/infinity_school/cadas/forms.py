from django import forms
from .models import FluxoModulos, CadastroModulo

class FluxoModulosForm(forms.ModelForm):
    class Meta:
        model = FluxoModulos
        fields = '__all__'

class CadastroModuloForm(forms.ModelForm):
    class Meta:
        model = CadastroModulo
        fields = '__all__'
