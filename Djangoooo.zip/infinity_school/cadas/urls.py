from django.urls import path
from .views import cadastro_modulo,fluxo_modulos
urlpatterns = [
    path('fluxo_modulos/', fluxo_modulos, name='fluxo_modulos'),
    path('cadastro_modulo/', cadastro_modulo, name='cadastro_modulo'),
]
