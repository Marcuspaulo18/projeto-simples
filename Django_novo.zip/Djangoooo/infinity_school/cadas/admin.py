from django.contrib import admin
from .models import CadastroModulo, FluxoModulos

admin.site.register(CadastroModulo)
admin.site.register(FluxoModulos)

