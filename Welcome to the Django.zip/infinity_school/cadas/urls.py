from django.urls import path
from . import views

urlpatterns = [
    path('cadas/', views.cadas, name='cadas'),
]