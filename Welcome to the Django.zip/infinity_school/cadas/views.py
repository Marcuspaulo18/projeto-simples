from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
def cadas(request):
    template = loader.get_template("cadastro_modulo.html")
    return HttpResponse(template.render())
