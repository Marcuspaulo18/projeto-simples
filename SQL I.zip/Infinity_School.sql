create database Infinity_School;
use Infinity_School;
create table info(
nome varchar(60),
local varchar(60));
insert into info values ("escola de artes e tecnologia infinity school","Salvador,fortaleza,Belo Horizonte");
select *from info
