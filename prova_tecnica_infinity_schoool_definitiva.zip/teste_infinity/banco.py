import pymysql

# Dados de acesso ao banco de dados
DB_HOST = '127.0.0.1'
DB_USER = 'root'
DB_PASSWORD = '7890_6543'
DB_NAME = 'infinito'

# Função para abrir conexão com o banco de dados
def abrir_conexao():
    return pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME)

# Função para autenticar o usuário (verificar se o e-mail e senha correspondem)
def autenticar_usuario(email, senha):
    conexao = abrir_conexao()
    try:
        with conexao.cursor() as cursor:
            sql = "SELECT * FROM `cadastro` WHERE `cadastro_email` = %s AND `cadastro_senha` = %s"
            cursor.execute(sql, (email, senha))
            resultado = cursor.fetchone()
            return resultado is not None
    except pymysql.Error as e:
        print(f"Erro ao autenticar usuário: {e}")
        return False
    finally:
        conexao.close()

# Função para deletar dados de uma tabela
def deletar_dados_da_tabela(tabela, condicao):
    conexao = abrir_conexao()
    try:
        with conexao.cursor() as cursor:
            sql = f"DELETE FROM `{DB_NAME}`.`{tabela}` WHERE {condicao}"
            cursor.execute(sql)
        conexao.commit()
        print("Dados deletados com sucesso")
    except pymysql.Error as e:
        print(f"Erro ao deletar dados da tabela: {e}")
    finally:
        conexao.close()

# Função para inserir dados em uma tabela
def inserir_dados_em_tabela(tabela, campos_colunas, linha):
    conexao = abrir_conexao()
    try:
        with conexao.cursor() as cursor:
            sql = f"INSERT INTO `{DB_NAME}`.`{tabela}` ({campos_colunas}) VALUES ({linha})"
            cursor.execute(sql)
        conexao.commit()
    except pymysql.Error as e:
        print(f"Erro ao inserir dados na tabela: {e}")
    finally:
        conexao.close()
