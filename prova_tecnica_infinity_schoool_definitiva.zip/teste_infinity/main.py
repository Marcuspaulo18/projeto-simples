from flask import Flask, render_template, request, jsonify, redirect, url_for
import banco  # Módulo contendo funções de interação com o banco de dados

import pymysql
import requests
import googlemaps
from datetime import datetime

# Inicialização do aplicativo Flask
app = Flask(__name__, template_folder="templates")

# Chave de API do Google Maps
API_KEY = 'AIzaSyDSAMZLmYUKij2oZDWtqFQOgJwtq7G_DBo'

# Inicialização do cliente Google Maps
gmaps = googlemaps.Client(key=API_KEY)


# Rota principal, redireciona para a rota de login
@app.route('/')
def home():
    return redirect(url_for('login'))


# Rota para calcular a entrega
@app.route('/calcular_entrega', methods=["POST"])
def calcular_entrega():
    if request.method == "POST":
        # Obter os dados do formulário
        pedido = request.form.get('pedido')
        cep_pi = request.form.get('cep_pi')
        endereco_pi = request.form.get('endereco_pi')
        cep_pf = request.form.get('cep_pf')
        endereco_pf = request.form.get('endereco_pf')

        # Consulta à API do Google Maps para obter a distância e o tempo
        url = f'https://maps.googleapis.com/maps/api/distancematrix/json?origins={cep_pi},{endereco_pi}&destinations={cep_pf},{endereco_pf}&key={API_KEY}'
        response = requests.get(url)
        data = response.json()

        # Verifica se a resposta da API contém dados
        if 'rows' in data and len(data['rows']) > 0 and 'elements' in data['rows'][0] and len(
                data['rows'][0]['elements']) > 0 and data['status'] == 'OK':
            # Extrai a distância e o tempo da resposta da API
            distancia = data['rows'][0]['elements'][0].get('distance', {}).get('text', 'N.O')
            tempo = data['rows'][0]['elements'][0].get('duration', {}).get('text', 'N.O')
            # Convertendo para valores numéricos
            distancia_t = float( data['rows'][0]['elements'][0].get('distance', {}).get('value', 0)) / 1000  # metros para km
            tempo_t = float(data['rows'][0]['elements'][0].get('duration', {}).get('value', 0)) / 60  # segundos para minutos
        else:

            distancia = 'N.O'
            tempo = 'N.O'
            distancia_t=0
            tempo_t=0
        try:
            banco.inserir_dados_em_tabela('entrega', 'pedido , distan ,temp', f"'{pedido}','{distancia}','{tempo}'")
        except Exception as e:
            return jsonify({'error': str(e)})

        # Retorne os dados para exibição no frontend
        return jsonify({'pedido': pedido, 'distancia': distancia_t,'tempo': tempo_t,'timestamp': datetime.now().timestamp()})

    else:
        return jsonify({'error': 'Método não permitido'})


# Rota de login
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        # Capturar os dados do formulário
        email_l = request.form['email_l']
        senha_l = request.form['senha_l']

        # Verificar autenticação do usuário
        if banco.autenticar_usuario(email_l, senha_l):
            banco.inserir_dados_em_tabela('logins', 'login_email, login_senha', f"'{email_l}', '{senha_l}'")
            # Usuário autenticado com sucesso
            return render_template("start.html")
        else:
            # Usuário não autenticado, redireciona para a página de login
            return redirect(url_for('login'))
    else:
        # Renderizar a página de login
        return render_template("login.html")


# Rota de cadastro
@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if request.method == "POST":
        # Capturar os dados do formulário
        usuario = request.form['usuario']
        email = request.form['email']
        senha = request.form['senha']
        cep = request.form['cep']
        endereco = request.form['endereco']

        try:
            # Inserir os dados no banco de dados
            banco.inserir_dados_em_tabela('cadastro',
                                          'cadastro_usuario, cadastro_email, cadastro_senha, cadastro_cep, cadastro_endereco',
                                          f"'{usuario}', '{email}', '{senha}', '{cep}', '{endereco}'")

            return render_template("cadastro.html", status='success')
        except Exception as e:
            # Se ocorrer uma exceção, redireciona de volta para a página de cadastro
            return render_template("cadastro.html", status='fail')
    else:
        status = request.args.get('status')
        # Renderizar a página de cadastro no caso de requisição GET
        return render_template("cadastro.html", status=status)

@app.route('/delete', methods=['POST'])
def delete_account():
    email = request.form['email_d']
    senha = request.form['senha_d']

    conexao = banco.abrir_conexao()
    try:
        with conexao.cursor() as cursor:
            sql_check = "SELECT * FROM `cadastro` WHERE `cadastro_email` = %s AND `cadastro_senha` = %s"
            cursor.execute(sql_check, (email, senha))
            resultado = cursor.fetchone()

            if resultado:
                condicao = f"`cadastro_email` = '{email}' AND `cadastro_senha` = '{senha}'"
                banco.deletar_dados_da_tabela('cadastro', condicao)
                return render_template('login.html', alert_message="Conta deletada com sucesso", alert_type="success")
            else:
                return render_template('login.html', alert_message="Email ou senha incorretos", alert_type="danger")
    except pymysql.Error as e:
        print(f"Erro ao deletar conta: {e}")
        return render_template('login.html', alert_message="Erro ao deletar conta", alert_type="danger")
    finally:
        conexao.close()

# Executar o aplicativo Flask
if __name__ == "__main__":
    app.run(debug=True)
